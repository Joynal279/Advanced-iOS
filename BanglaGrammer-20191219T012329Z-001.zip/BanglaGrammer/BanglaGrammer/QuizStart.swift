//
//  QuizStart.swift
//  Application
//
//  Created by Admin on 08/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class QuizStart: UIViewController {
      let index = UserDefaults.standard.integer(forKey: "index")
    var str=""
    //var user=""
//    switch str {
//    
//    print("sondi")
//    }
    let question = ["কারক নির্ণয় করার সহজ উপায় :","তিলে তৈল হয় -এখানে তিলে কোন কারকে কোন বিভক্তি ?","বনে বাঘ আছে - বনে কোন কারকে কোন বিভক্তি ?"]
    let answers = [["শব্দটিকে ভাঙা","বিশেষ্যকে প্রশ্ন করা","বিশেষণকে প্রশ্ন করা","ক্রিয়াকে প্রশ্ন করা"],["কর্মে সপ্তমী","অপাদানে সপ্তমী","করণে তৃতীয়া","অধিকরণে পঞ্চমী"],["বৈষয়িক অধিকরণ","ভাবাধিকরণ","ঐকদেশিক অধিকরণ","অভিব্যাপক অধিকরণ"]]
    let q = ["কাজলকালো - এর সঠিক ব্যাসবাক্য কোনটি?","প্রগতি - কোন সমাসের উদাহরণ?","মহানবি - শব্দটি কোন সমাস?","উপমান কর্মধারয় সমাস কাকে বলে?","জীবননাশের আশঙ্কায় যে বীমা = জীবনবীমা- কোন কর্মধারয় সমাস?","কয়টি সমাসের সাথে  `অলুক`  কথাটি যুক্ত আছে?","জলচর কোন তৎপুরুষসমাস?","উপনদী সমস্তপদের উপ কী অর্থে ব্যবহৃত হয়েছে?","রূপককর্মধারয় - এর সমস্তপদ কোনটি?","পঙ্কজ কোন তৎপুরুষনিষ্পন্ন শব্দ?"]
    let a = [["কাজলের ন্যায় কালো","কাজল রূপকালো","কাজল ও কালো","কালো যে কাজল"],["প্রাদি সমাস","নিত্য সমাস","অব্যয়ীভাব সমাস","অলুক সমাস"], ["কর্মধারয়","তৎপুরুষ","অব্যয়ীভাব","বহুব্রীহি"],["দৃশ্যমান বস্তুর সাথে অদৃশ্যমান বস্তুর মিল থাকলে","অদৃশ্য বস্তুর সাথে দৃশ্যমান বস্তুর মিল থাকলে","সাধারণ গুণের উল্লেখ থাকলে","দুটি বিশেষ পদের একটিকে বুঝায়"],["মধ্যপদলোপী","উপমান","উপমিত","রূপক"],["৩","২","৪","৬"],["সপ্তমী","পঞ্চমী","উপপদ","তৃতীয়া"],["ক্ষুদ্র","অভাব","সামীপ্য","সাদৃশ্য"],["বিষাদসিন্ধু","মহাপুরুষ","তুষারশুভ্র","ঘনশ্যাম"],["উপপদ","অলুক","সপ্তমী","দ্বিতীয়া"]]

    var currentQuestion=0
    var rightAnswerPlacement:UInt32=0
    var points=0
    @IBOutlet weak var output: UILabel!
    @IBOutlet weak var lbl: UILabel!
    @IBAction func action(_ sender: AnyObject) {
        switch index {
        case 0:
            if((sender as AnyObject).tag == Int(rightAnswerPlacement)){
                print("correct")
                points += 10
                
            }
            else{
                print("wrong!!")
            }
            if(currentQuestion != question.count){
                newQuestion()
            }
            else if currentQuestion == question.count {
                endQuiz()
            }
        case 1:
            
            if((sender as AnyObject).tag == Int(rightAnswerPlacement)){
                print("correct")
                points += 10
                
            }
            else{
                print("wrong!!")
            }
            if(currentQuestion != q.count){
                newQuestion()
            }
            else if currentQuestion == q.count {
                endQuiz()
            }
        default:
            print("something wrong")
        }
        
    }
    override func viewDidAppear(_ animated: Bool) {
        newQuestion()
    }
    func newQuestion(){
        switch index {
        case 0:
            lbl.text = question[currentQuestion]
            rightAnswerPlacement = arc4random_uniform(4)+1
            var button:UIButton=UIButton()
            var x = 1
            for i in 1...4{
                button = view.viewWithTag(i) as! UIButton
                if(i==Int(rightAnswerPlacement)){
                    button.setTitle(answers[currentQuestion][0], for: .normal)
                }
                else {
                    button.setTitle(answers[currentQuestion][x], for: .normal)
                    x += 1
                }
            }
            currentQuestion += 1
        case 1:
            lbl.text = q[currentQuestion]
            rightAnswerPlacement = arc4random_uniform(4)+1
            var button:UIButton=UIButton()
            var x = 1
            for i in 1...4{
                button = view.viewWithTag(i) as! UIButton
                if(i==Int(rightAnswerPlacement)){
                    button.setTitle(a[currentQuestion][0], for: .normal)
                }
                else {
                    button.setTitle(a[currentQuestion][x], for: .normal)
                    x += 1
                }
            }
            currentQuestion += 1
        default:
            print("something wrong")
        }
        
    }
    
    func endQuiz(){
        if points == 30 {
            print("Pass the exam !!")
        }
        else{
            print("Fail the exam!!!!")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
        
        output.text=str
        
      
        
//        print("Index \(index)")
//        switch index {
//        case 0:
//            
//            somas()
//        case 1:
//            print("index 1")
//        case 2:
//            print("index 2")
//        default:
//            print("nothing found")
//        }
//       
        
        //UserDefaults.standard.set(nil, forKey: "index")
        
        //serDefaults.standard.removeObject(forKey: index)
        print("index after nill :\(index)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
   

}
