//
//  TableView.swift
//  Application
//
//  Created by Admin on 08/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class TableView: UITableViewController {

    var grammer = ["সন্ধি","সমাস","প্রত্যয়","বিশেষণ","সর্বনাম","ক্রিয়ার কাল","ক্রিয়াপদ","বিভক্তি","কারক","অনুসর্গ","পদ"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return grammer.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        cell.textLabel?.text=grammer[indexPath.row]
        cell.backgroundColor=UIColor.blue
        cell.textLabel?.textColor=UIColor.white
     // cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "cell")
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.font=UIFont.systemFont(ofSize:30)
        //cell.textLabel?.layer.borderColor=UIColor.black.cgColor
        //cell.textLabel?.layer.cornerRadius=5
        

        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier:"quizPage", sender: self)
    }
    

}
