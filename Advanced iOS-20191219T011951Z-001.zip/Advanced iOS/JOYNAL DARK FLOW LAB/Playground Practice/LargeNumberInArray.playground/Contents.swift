import UIKit

var interestingNumber = [
    "p" : [22,33,1,5,6,77,9],
    "q" : [4,6,33,100,22,55]
    
]
var final = 0
for (key,value) in interestingNumber {
    for number in value {
        if number > final {
            final = number
        }
    }
}
print("the largest number \(final)")
