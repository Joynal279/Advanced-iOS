import UIKit
//
//class MarkStruct {
//    var mark: Int
//    init(mark: Int){
//        self.mark = mark
//    }
//
//}
//class Marked: MarkStruct {
//    func fun(){
//        print("hello \(mark)")
//    }
//}
//var obj = Marked(mark:)
//obj.mark = 39


class SampleClass: Equatable {
    let myProperty: String
    init(s: String) {
        myProperty = s
    }
}

func ==(lhs: SampleClass, rhs: SampleClass) -> Bool {
    return lhs.myProperty == rhs.myProperty
}

let spClass1 = SampleClass(s: "Hello")
let spClass2 = SampleClass(s: "Hello")

spClass1 === spClass2 // false
print("\(spClass1)")

//spClass1 !== spClass2 // true
//print("\(spClass2)")


let dic = ["name": 2, "id": 3]

let array = Array(dic)

print("Array in \(array)")


let key = dic.keys

let final = Array(key)

print("Key \(final)")
