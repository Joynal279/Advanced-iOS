import UIKit

func function(name: String, day: String) -> String{
    return "name :\(name) day :\(day)"
}

print(function(name: "joy", day: "sunday"))
