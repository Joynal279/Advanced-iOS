import UIKit

var imojiDict: [String: String] = ["😡":"Engry","😍":"Love For Kid Aid","😥":"Crying","💀":"Ghost","👾":"Alien Monstar"]

for (key,value) in imojiDict {
    print("\(key) : \(value)")
}
var wordToLookup = "😍"
var meaning = imojiDict[wordToLookup]
let containerView = UIView(frame: CGRect(x: 2, y: 2, width: 300, height: 300))
containerView.backgroundColor=UIColor.blue
let imojiLabel = UILabel(frame: CGRect(x: 95, y: 20, width: 150, height: 150))
imojiLabel.text = wordToLookup
imojiLabel.font = UIFont.systemFont(ofSize: 100)
containerView.addSubview(imojiLabel)

let meaningLabel = UILabel(frame: CGRect(x: 10, y: 140, width: 500, height: 100))
meaningLabel.text = meaning
meaningLabel.font = UIFont.systemFont(ofSize: 40)
meaningLabel.textColor = UIColor.white
containerView.addSubview(meaningLabel)

