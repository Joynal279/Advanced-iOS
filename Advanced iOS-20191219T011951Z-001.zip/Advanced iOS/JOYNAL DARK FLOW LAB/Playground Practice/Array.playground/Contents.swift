import UIKit

//var numbers = [45,73,195,53]
//for value in 0..<numbers.count {
//    print("value \(numbers[value])")
//}

func function(name: Int...) -> Int {
    var sum = 0
    for number in name {
        sum = sum + number
    }
    return sum
}
print(function(name :22,34,55,66,12))
