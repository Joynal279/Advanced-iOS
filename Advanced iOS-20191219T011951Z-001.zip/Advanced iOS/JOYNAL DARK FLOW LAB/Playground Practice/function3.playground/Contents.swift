import UIKit

func fifteen() -> Int {
    var num = 10
    func add(){
         num = num + 10
        
    }
    add()
    return num
    
}
print("The value \(fifteen())")
