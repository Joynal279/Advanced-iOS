import UIKit

for value in 0..<5   {
    print("The value \(value)")
}
