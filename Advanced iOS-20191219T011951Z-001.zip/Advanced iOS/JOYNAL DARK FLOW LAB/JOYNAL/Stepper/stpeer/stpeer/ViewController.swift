//
//  ViewController.swift
//  stpeer
//
//  Created by Flowdigital Media01 on 12/1/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var output: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func steeperAction(_ sender: UIStepper) {
        output.text=String(sender.value)
    }
    
}

