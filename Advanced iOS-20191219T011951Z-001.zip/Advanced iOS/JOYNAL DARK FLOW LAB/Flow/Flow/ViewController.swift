//
//  ViewController.swift
//  Flow
//
//  Created by USER on 05/12/19.
//  Copyright © 2019 USER. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func showMessage(sender: UIButton){
        let alert = UIAlertController(title: "বাংলা ব্যাকরণ এপ্স", message: "আপনি কি বের হতে চান ?🔍", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "হ্যাঁ👿", style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "না😎", style: .cancel, handler: nil))
        
        self.present(alert, animated: true)
        
        
    }


}

