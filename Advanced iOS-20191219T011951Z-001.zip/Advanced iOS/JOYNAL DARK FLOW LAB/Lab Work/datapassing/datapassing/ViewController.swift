//
//  ViewController.swift
//  datapassing
//
//  Created by Flowdigital Media01 on 11/27/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var input: UITextField!
 
    @IBAction func action(_ sender: Any) {
        
        performSegue(withIdentifier: "second", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let obj = segue.destination as! page2
        obj.str=input.text!
    }
    
}

