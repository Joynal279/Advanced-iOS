//
//  page2.swift
//  datapassing
//
//  Created by Flowdigital Media01 on 11/27/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class page2: UIViewController {
    var str=""
    
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        label.text=str 
        // Do any additional setup after loading the view.
    }
    


}
