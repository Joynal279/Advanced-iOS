//
//  page2.swift
//  dataproject
//
//  Created by Flowdigital Media01 on 11/27/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class page2: NSObject {

}
