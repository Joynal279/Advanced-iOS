//
//  ViewController.swift
//  test
//
//  Created by Flowdigital Media01 on 12/1/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        showToast()
    }


    
    func showToast(){
        
        print("Toast ")
        let toastMessage = UILabel()
        toastMessage.frame=CGRect(x: 100, y: 100, width: 200, height: 60)
        toastMessage.text="Registration Successfully!"
        toastMessage.textAlignment = .center
        toastMessage.backgroundColor=UIColor.blue
        toastMessage.textColor=UIColor.black
        self.view.addSubview(toastMessage)
        UIView.animate(withDuration: 5.0, delay: 2.0, options: .curveEaseInOut, animations: {
            toastMessage.alpha = 0.0
        }) {(iscompleted) in
            toastMessage.removeFromSuperview()
        }
    }
    
}

