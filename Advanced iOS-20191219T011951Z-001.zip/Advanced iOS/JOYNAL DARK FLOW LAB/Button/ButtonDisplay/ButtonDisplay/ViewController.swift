//
//  ViewController.swift
//  ButtonDisplay
//
//  Created by Flowdigital Media01 on 8/1/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var input: UITextField!
    @IBAction func button(_ sender: Any) {
        label.text=input.text
    }
    

}

