//
//  login.swift
//  UISwitch
//
//  Created by Flowdigital Media01 on 11/27/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.  \
//

import UIKit

class login: UIViewController {
    
    @IBOutlet weak var login: UILabel!
    var checkToast = false
    var str = ""
    var str1 = ""
    @IBOutlet weak var name1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        checkToast = UserDefaults.standard.bool(forKey: "check")
        
        if checkToast{
            
            UIView.animate(withDuration: 5, delay: 1, options: [], animations: {
                self.login.text = "Successfully Login"
                
            })
            
        }

        // Do any additional setup after loading the view.
        name1.text=str
        pass1.text=str1
        
        
     //   if checkToast == true{

    //    }

//        UserDefaults.standard.set(false, forKey: "check")
//
//        let name = UserDefaults.standard.bool(forKey: "check")
//        print("check  \(name)")
      
    }
    @IBOutlet weak var pass1: UITextField!
    
    
    
    func showToast(){
        
        print("Toast ")
        let toastMessage = UILabel()
        toastMessage.frame=CGRect(x: 100, y: 100, width: 200, height: 60)
        toastMessage.text="Registration Successfully!"
        toastMessage.textAlignment = .center
        toastMessage.backgroundColor=UIColor.red
        toastMessage.textColor=UIColor.black
        self.view.addSubview(toastMessage)
        UIView.animate(withDuration: 5.0, delay: 2.0, options: .curveEaseInOut, animations: {
            toastMessage.alpha = 2.0
        }) {(iscompleted) in
            toastMessage.removeFromSuperview()
        }
    }
    
    
    func showToastt(message: String) {
        let toastLabel = UITextView(frame: CGRect(x: self.view.frame.size.width/16, y: self.view.frame.size.height-150, width: self.view.frame.size.width * 7/8, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.text = "   \(message)   "
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        toastLabel.font = UIFont(name: (toastLabel.font?.fontName)!, size: 16)
     //   toastLabel.alpha = 1.0
//        toastLabel.layoutEdgeInsets.left = 8
//        toastLabel.layoutEdgeInsets.right = 8
        toastLabel.center.x = self.view.frame.size.width/2
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 5.0, delay: 0.1, options: [], animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }

}
