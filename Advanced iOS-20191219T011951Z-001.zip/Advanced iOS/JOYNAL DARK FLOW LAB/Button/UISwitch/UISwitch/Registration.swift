//
//  Registration.swift
//  UISwitch
//
//  Created by Flowdigital Media01 on 11/27/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class Registration: UIViewController {
    var checkEmpty = true

    @IBOutlet weak var name2: UITextField!
    @IBOutlet weak var email2: UITextField!
    @IBOutlet weak var pass2: UITextField!
    @IBOutlet weak var compass2: UITextField!
    @IBAction func input(_ sender: Any) {
       
      //  showToast()
        checkTxtField(check: name2)
        checkTxtField(check: email2)
        checkTxtField(check: pass2)
        
        if checkEmpty{
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            
            let resultViewController = storyBoard.instantiateViewController(withIdentifier: "login")  as! login
            
            self.present(resultViewController, animated:true, completion:nil)
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
      
        
        UserDefaults.standard.set(true, forKey: "check")
        
        
     
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func showToast(){
        let toastMessage = UILabel()
        toastMessage.frame=CGRect(x: 1000, y: 100, width: 200, height: 60)
        toastMessage.text="Registration Successfully!"
        toastMessage.textAlignment = .center
        toastMessage.backgroundColor=UIColor.red
        toastMessage.textColor=UIColor.black
        self.view.addSubview(toastMessage)
        UIView.animate(withDuration: 2.0, delay: 1.0, options: .curveEaseInOut, animations: {
            toastMessage.alpha=0.0
        }) {(iscompleted) in
            toastMessage.removeFromSuperview()
        }
        }
    
    func checkTxtField(check: UITextField){
    
        let value = check.text
        if (value?.isEmpty)!{
            
            checkEmpty = false
            
            let borderColor = UIColor.red
            check.layer.borderWidth = 2.0
            check.layer.borderColor = borderColor.cgColor
            
            
        }
        
        
    }
    

}
