//
//  ViewController.swift
//  UISwitch
//
//  Created by Flowdigital Media01 on 11/27/19.
//  Copyright © 2019 Flowdigital Media01. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var label: UIView!
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var action2: UISwitch!
    @IBOutlet var action: UIView!
    @IBAction func actionInput(_ sender: UISwitch) {
        
        UserDefaults.standard.set(false, forKey: "check")
        
        if action2.isOn {
            label1.text="ON"
            view.backgroundColor=UIColor.green
        }
        else{
            label1.text="OFF"
            view.backgroundColor=UIColor.red
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        label1.text="OFF"
        // Do any additional setup after loading the view, typically from a nib.
    }


}

