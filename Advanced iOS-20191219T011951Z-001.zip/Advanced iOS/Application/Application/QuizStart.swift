//
//  QuizStart.swift
//  Application
//
//  Created by Admin on 08/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class QuizStart: UIViewController {
    var str=""
    //var user=""
//    switch str {
//    
//    print("sondi")
//    }
    @IBOutlet weak var output: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        output.text=str
        
        let index = UserDefaults.standard.integer(forKey: "index")
        
        print("Index \(index)")
        switch index {
        case 0:
            print("Index 0")
        case 1:
            print("index 1")
        case 2:
            print("index 2")
        default:
            print("nothing found")
        }
       
        
        //UserDefaults.standard.set(nil, forKey: "index")
        
        //serDefaults.standard.removeObject(forKey: index)
        print("index after nill :\(index)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
